package wms.cloud.outbound.ordercenter.service.order;

import com.jd.wms.stock.domain.stock.StStockM;

/**
 * @Description:
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 11:25 AM
 * @Version: 1.0
 */
public interface OrderService {
    boolean insertStock(StStockM bean);
}
