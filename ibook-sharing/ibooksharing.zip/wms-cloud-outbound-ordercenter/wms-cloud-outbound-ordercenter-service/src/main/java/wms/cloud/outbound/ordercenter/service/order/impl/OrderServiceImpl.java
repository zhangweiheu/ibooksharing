package wms.cloud.outbound.ordercenter.service.order.impl;

import com.jd.wms.stock.domain.stock.StStockM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wms.cloud.outbound.ordercenter.manager.order.OrderManager;
import wms.cloud.outbound.ordercenter.service.order.OrderService;

/**
 * @Description: 业务层
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 11:23 AM
 * @Version: 1.0
 */
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderManager orderManager;

    public boolean insertStock(StStockM bean){
       return orderManager.insertStockM(bean);
    }
}
