package com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(targetNamespace = "http://wms3.360buy.com", name = "BaseWebService")
public interface BaseWebService {

    @WebResult(name = "return", targetNamespace = "")
    @RequestWrapper(localName = "queryWs", targetNamespace = "http://wms3.360buy.com", className = "com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.QueryWs")
    @ResponseWrapper(localName = "queryWsResponse", targetNamespace = "http://wms3.360buy.com", className = "com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.QueryWsResponse")
    @WebMethod
    public Result queryWs(@WebParam(name = "arg0", targetNamespace = "") String arg0, @WebParam(name = "arg1", targetNamespace = "") String arg1);

    @WebResult(name = "return", targetNamespace = "")
    @RequestWrapper(localName = "processWs", targetNamespace = "http://wms3.360buy.com", className = "com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.ProcessWs")
    @ResponseWrapper(localName = "processWsResponse", targetNamespace = "http://wms3.360buy.com", className = "com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.ProcessWsResponse")
    @WebMethod
    public Result processWs(@WebParam(name = "arg0", targetNamespace = "") String arg0, @WebParam(name = "arg1", targetNamespace = "") String arg1);
}
