package com.jd.wms.cloud.outbound.ordercenter.domain.rpc.service.impl;

import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.BaseWebService;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.Result;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.service.Wms3MessageRpc;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wms5 WebService 客户端 实现
 * User: YinWei
 * DateTime: 2012-6-27 9:27:32
 * Version: 1.0
 */
public class Wms3MessageRpcImpl implements Wms3MessageRpc {
    private static final Logger log = LoggerFactory.getLogger(Wms3MessageRpcImpl.class);

    /**
     * Wms3 客户端自动生成接口（CXF）
     */
    private BaseWebService clientWebServiceSoap;

    public Result processWs(String bizToken, String bizXml) {
        if (StringUtils.isNotBlank(bizToken) && StringUtils.isNotBlank(bizXml)) {
            return clientWebServiceSoap.processWs(bizToken, bizXml);
        } else {
            log.error("Wms3MessageRpcImpl!processWs -> param is null");
        }
        return null;
    }

    public Result queryWs(String bizToken, String bizXml) {
        if (StringUtils.isNotBlank(bizToken) && StringUtils.isNotBlank(bizXml)) {
            return clientWebServiceSoap.queryWs(bizToken, bizXml);
        } else {
            log.error("Wms3MessageRpcImpl!queryWs -> param is null");
        }
        return null;
    }

    public void setClientWebServiceSoap(BaseWebService clientWebServiceSoap) {
        this.clientWebServiceSoap = clientWebServiceSoap;
    }
}
