package com.jd.wms.cloud.outbound.ordercenter.domain.common;

/**
 * @Description: 客户端类型枚举
 * @Author: zhangwei12
 * @DateTime: 2017-11-07 2:15 PM
 * @Version: 1.0
 */
public enum ClientTypeEnum {
    WEB(1, "Web与PC"), RF(2, "RF设备"), ANDROID(3, "安卓");

    private int value;

    private String describe;

    ClientTypeEnum(int value, String describe) {
        this.value = value;
        this.describe = describe;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }
}
