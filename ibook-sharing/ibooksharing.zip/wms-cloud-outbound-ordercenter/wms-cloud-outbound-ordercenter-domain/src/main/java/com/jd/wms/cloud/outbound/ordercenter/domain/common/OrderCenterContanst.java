package com.jd.wms.cloud.outbound.ordercenter.domain.common;

/**
 * @Description:
 * @Author: zhangwei12
 * @DateTime: 2017-11-10 6:07 PM
 * @Version: 1.0
 */
public interface OrderCenterContanst {
    String SPLIT = ",";
    String ROUTERULE = "routeRule";
}
