package com.jd.wms.cloud.outbound.ordercenter.domain.common;

/**
 * @Description: 消息码
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 9:16 PM
 * @Version: 1.0
 */
public interface MessageCode {
    String ApplicationError = "ApplicationError";
}
