package com.jd.wms.cloud.outbound.ordercenter.domain.user;

import com.jd.wms.cloud.outbound.ordercenter.domain.common.ClientTypeEnum;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @Description: 请求菜单信息的DTO
 * @Author: zhangwei12
 * @DateTime: 2017-11-07 2:11 PM
 * @Version: 1.0
 */
public class UserDTO extends UserInfo {
    /**
     * 菜单类型
     */
    @NotBlank(message = "菜单类型不能为空")
    private ClientTypeEnum clientType;


    public ClientTypeEnum getClientType() {
        return clientType;
    }

    public void setClientType(ClientTypeEnum clientType) {
        this.clientType = clientType;
    }
}
