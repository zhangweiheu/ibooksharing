package com.jd.wms.cloud.outbound.ordercenter.domain.common;

/**
 * @Description: 基础信息
 * @Author: zhangwei12
 * @DateTime: 2017-10-26 10:04 AM
 * @Version: 1.0
 */
public class BaseDomain {
    /**
     * 机构编号
     */
    private String orgNo;

    /**
     * 机构名称
     */
    private String orgName;

    /**
     * 配送中心编号
     */
    private String distributeNo;

    /**
     * 配送中心名称
     */
    private String distributeName;

    /**
     * 仓库编号
     */
    private String warehouseNo;

    /**
     * 仓库名称
     */
    private String warehouseName;

    public String getOrgNo() {
        return orgNo;
    }

    public void setOrgNo(String orgNo) {
        this.orgNo = orgNo;
    }

    public String getWarehouseNo() {
        return warehouseNo;
    }

    public void setWarehouseNo(String warehouseNo) {
        this.warehouseNo = warehouseNo;
    }

    public String getDistributeNo() {
        return distributeNo;
    }

    public void setDistributeNo(String distributeNo) {
        this.distributeNo = distributeNo;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDistributeName() {
        return distributeName;
    }

    public void setDistributeName(String distributeName) {
        this.distributeName = distributeName;
    }

    public String getWarehouseName() {
        return warehouseName;
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }
}
