package com.jd.wms.cloud.outbound.ordercenter.domain.common;

/**
 * @Description: Http头部字段枚举
 * @Author: zhangwei12
 * @DateTime: 2017-11-20 9:10 AM
 * @Version: 1.0
 */
public enum HttpHeaderEnum {
    Lang("lang", "请求头语言"),
    Accept_Language("Accept-Language", "接受的语言"),
    Proxy_Authorization("Proxy-Authorization", "连接代理授权认证信息"),
    Authorization("Authorization", "HTTP身份验证的凭证");


    private String key;
    private String describe;

    HttpHeaderEnum(String key, String describe) {
        this.key = key;
        this.describe = describe;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }
}
