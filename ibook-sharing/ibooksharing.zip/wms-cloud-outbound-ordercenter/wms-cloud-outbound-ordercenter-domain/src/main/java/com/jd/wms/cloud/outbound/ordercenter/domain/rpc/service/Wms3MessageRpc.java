package com.jd.wms.cloud.outbound.ordercenter.domain.rpc.service;



import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.Result;

/**
 * Wms3.0 WebService 客户端接口
 * User: YinWei
 * DateTime: 2012-6-21 13:47:14
 * Version: 1.0
 */
public interface Wms3MessageRpc {

    /**
     * 操作类型的WebService方法定义
     *
     * @param bizToken 实现类需要解析用来业务转发参数
     * @param bizXml   实现业务操作时需要的参数
     * @return 返回结果，业务可以自定义
     */
    public Result processWs(String bizToken, String bizXml);

    /**
     * 查询类型的WebService方法定义
     *
     * @param bizToken 实现类需要解析用来业务转发参数
     * @param bizXml   实现业务操作时需要的参数
     * @return 返回结果，业务可以自定义，该参数中可以存储返回集合
     */
    public Result queryWs(String bizToken, String bizXml);
}
