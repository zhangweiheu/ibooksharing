package com.jd.wms.cloud.outbound.ordercenter.domain.user;

import com.jd.wms.domain.wms3.master.ws.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @Description: 校验测试异常信息
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 9:21 PM
 * @Version: 1.0
 */
@ApiModel("用户信息")
public class UserInfo extends User {
    @ApiModelProperty("用户码")
    private String userCode;

    @ApiModelProperty("用户账号")
    private String userAccount;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("测试字段")
    @NotBlank(message = "{NotBlank.zhangwei}")
    @Length(min = 5, max = 30, message = "{Length.zhangwei}")
    private String zhangwei;

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getZhangwei() {
        return zhangwei;
    }

    public void setZhangwei(String zhangwei) {
        this.zhangwei = zhangwei;
    }
}
