package com.jd.wms.cloud.outbound.ordercenter.dao;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

/**
 * @Description: DAO config
 * @Author: zhangwei12
 * @DateTime: 2017-10-27 3:24 PM
 * @Version: 1.0
 */
@Configuration
@ComponentScan(basePackages = {"com.jd.wms.cloud.outbound.ordercenter.dao"},
        excludeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class)})
@MapperScan(value = "com.jd.wms.cloud.outbound.ordercenter.dao", sqlSessionFactoryRef = "sqlSessionFactory")
public class DaoConfig {
}
