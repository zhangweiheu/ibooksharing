package com.jd.wms.cloud.outbound.ordercenter.dao.mapper;

import com.jd.wms.stock.domain.stock.StStockM;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description: 订单信息
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 11:31 AM
 * @Version: 1.0
 */
@Mapper
public interface OrderMapper {
    Long insert(StStockM bean);

    StStockM selectOne(StStockM bean);
}
