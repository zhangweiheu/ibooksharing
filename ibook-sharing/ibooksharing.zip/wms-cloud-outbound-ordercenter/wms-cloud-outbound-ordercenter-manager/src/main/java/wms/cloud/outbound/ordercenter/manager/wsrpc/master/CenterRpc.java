package wms.cloud.outbound.ordercenter.manager.wsrpc.master;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.wms.cloud.outbound.ordercenter.domain.common.BaseDomain;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.Result;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.service.Wms3MessageRpc;
import com.jd.wms.cloud.outbound.ordercenter.domain.user.UserDTO;
import com.jd.wms.domain.wms3.master.query.ReValue;
import com.jd.wms.domain.ws.receivemessage.param.BizToken;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

;

/**
 * @Description: Center远程服务
 * @Author: zhangwei12
 * @DateTime: 2017-10-26 6:52 PM
 * @Version: 1.0
 */
@Component(value = "centerRpc")
public class CenterRpc {
    private static final Logger logger = LoggerFactory.getLogger(CenterRpc.class);

    @Autowired
    @Qualifier(value = "centerMessageRpc")
    private Wms3MessageRpc centerMessageRpc;

    @Resource
    private BizToken loadParkOrgNo;

    @Resource
    private BizToken loadParkDcNoByOrgNoToken;

    @Resource
    private BizToken loadParkHouseByDcNoToken;

    @Resource
    private BizToken getPCMenuInfoByUserInfoToken;

    @Resource
    private BizToken getRFMenuInfoByUserInfoToken;

    @Resource
    private BizToken getAndroidMenuInfoByUserInfoToken;

    /**
     * 获取库房信息
     * 本方法是特殊的接口，违背SRP原则，但是因为后续需要整合，故本次放在同一方法中,
     * RPC方法使用时务必谨慎对待，防止出现分布式事务问题
     *
     * @return List<BaseDomain>
     */
    public List<BaseDomain> getWarehouseInfo() {
        List<BaseDomain> warehouseList = new ArrayList<BaseDomain>();
        List<ReValue> orgList = null;
        List<ReValue> disList = null;
        List<ReValue> wareList = null;
        Result result = centerMessageRpc.queryWs(JSONObject.toJSONString(loadParkOrgNo), "-1");
        if (result == null || result.getResultCode() != 1) {
            return warehouseList;
        }
        orgList = JSONArray.parseArray(result.getResultValue(), ReValue.class);
        for (ReValue orgValue : orgList) {
            BaseDomain domain = new BaseDomain();
            domain.setOrgNo(orgValue.getCode());
            domain.setOrgName(orgValue.getName());
            result = centerMessageRpc.queryWs(JSONObject.toJSONString(loadParkDcNoByOrgNoToken), StringUtils.isBlank(orgValue.getCode()) ?
                    "-1" :
                    orgValue.getCode());
            if (result == null || result.getResultCode() != 1) {
                continue;
            }
            disList = JSONArray.parseArray(result.getResultValue(), ReValue.class);

            for (ReValue reValue : disList) {
                domain.setDistributeNo(reValue.getCode());
                domain.setDistributeName(reValue.getName());
                result = centerMessageRpc.queryWs(JSONObject.toJSONString(loadParkHouseByDcNoToken), JSONObject.toJSONString(domain));
                if (result == null || result.getResultCode() != 1) {
                    continue;
                }
                wareList = JSONArray.parseArray(result.getResultValue(), ReValue.class);

                for (ReValue wareValue : wareList) {
                    BaseDomain warehouse = new BaseDomain();
                    BeanUtils.copyProperties(domain, warehouse);
                    warehouse.setWarehouseNo(wareValue.getCode());
                    warehouse.setWarehouseName(wareValue.getName());
                    warehouseList.add(warehouse);
                }
            }
        }
        return warehouseList;
    }

    /**
     * 获取菜单信息统一接口
     *
     * @param user
     * @return
     */
    public Map<String, Object> getMenuInfoByUserInfo(UserDTO user) {
        Map<String, String> parameter = new HashMap<String, String>();

        parameter.put("account", user.getUserName());
        parameter.put("pwd", user.getPassword());
        parameter.put("warehouseNo", user.getWarehouseNo());
        parameter.put("orgNo", user.getOrgNo());
        parameter.put("distributeNo", user.getDistributeNo());

        Map<String, Object> resultMenuInfo = null;
        switch (user.getClientType()) {
            case WEB:
                resultMenuInfo = getPCMenuInfoByUserInfo(parameter);
                break;
            case RF:
                resultMenuInfo = getRFMenuInfoByUserInfo(parameter);
                break;
            case ANDROID:
                resultMenuInfo = getAndroidMenuInfoByUserInfo(parameter);
                break;
            default:
                break;
        }
        if (null == resultMenuInfo) {
            return null;
        }
        return resultMenuInfo;
    }

    /**
     * 根据用户信息获取其PC菜单信息
     *
     * @param parameter
     * @return
     */
    private Map<String, Object> getPCMenuInfoByUserInfo(Map<String, String> parameter) {
        Result result = centerMessageRpc.queryWs(JSONObject.toJSONString(getPCMenuInfoByUserInfoToken), JSONObject.toJSONString(parameter));
        if (result == null || result.getResultCode() != 1) {
            logger.error(JSONObject.toJSONString(result));
            return null;
        }

        Map<String, Object> resultMap = JSONObject.parseObject(result.getResultValue(), Map.class);

        return resultMap;
    }

    /**
     * 根据用户信息获取其RF菜单信息
     *
     * @param parameter
     * @return
     */
    private Map<String, Object> getRFMenuInfoByUserInfo(Map<String, String> parameter) {
        Result result = centerMessageRpc.queryWs(JSONObject.toJSONString(getRFMenuInfoByUserInfoToken), JSONObject.toJSONString(parameter));
        if (result == null || result.getResultCode() != 1) {
            logger.error(JSONObject.toJSONString(result));
            return null;
        }

        Map<String, Object> resultMap = JSONObject.parseObject(result.getResultValue(), Map.class);

        return resultMap;
    }

    /**
     * 根据用户信息获取其安卓菜单信息
     *
     * @param parameter
     * @return
     */
    private Map<String, Object> getAndroidMenuInfoByUserInfo(Map<String, String> parameter) {
        Result result = centerMessageRpc.queryWs(JSONObject.toJSONString(getAndroidMenuInfoByUserInfoToken), JSONObject.toJSONString(parameter));
        if (result == null || result.getResultCode() != 1) {
            logger.error(JSONObject.toJSONString(result));
            return null;
        }

        Map<String, Object> resultMap = JSONObject.parseObject(result.getResultValue(), Map.class);

        return resultMap;
    }
}
