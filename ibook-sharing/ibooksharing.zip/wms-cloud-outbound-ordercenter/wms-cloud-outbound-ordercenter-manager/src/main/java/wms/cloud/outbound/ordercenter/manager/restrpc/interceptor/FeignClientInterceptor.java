//package wms.cloud.outbound.ordercenter.manager.restrpc.interceptor;
//
//import com.jd.wms.cloud.outbound.ordercenter.domain.common.HttpHeaderEnum;
//import com.jd.wms.util.common.CommonUtil;
//import feign.RequestInterceptor;
//import feign.RequestTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.util.Enumeration;
//
///**
// * @Description: feign client rpc 拦截设置请求头信息,携带token,routerule,locale等信息
// * @Author: zhangwei12
// * @DateTime: 2017-11-16 3:27 PM
// * @Version: 1.0
// */
//@Component
//public class FeignClientInterceptor implements RequestInterceptor {
//    @Autowired
//    private HttpServletRequest request;
//
//    @Override
//    public void apply(RequestTemplate template) {
//        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).get;
//        Enumeration<String> headerNames = request.getHeaderNames();
//        if (headerNames != null) {
//            while (headerNames.hasMoreElements()) {
//                String name = headerNames.nextElement();
//                if (CommonUtil.ROUTER_KEY.equals(name) || HttpHeaderEnum.Authorization.getKey().equals(name)
//                        || HttpHeaderEnum.Lang.getKey().equals(name)) {
//                    String values = request.getHeader(name);
//                    template.header(name, values);
//                }
//            }
//        }
//    }
//}
