package wms.cloud.outbound.ordercenter.manager.restrpc.EnDecoder;

import com.alibaba.fastjson.JSONObject;
import feign.FeignException;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;
import feign.codec.Decoder;

import java.io.IOException;
import java.lang.reflect.Type;

/**
 * @Description: 自定义json解码
 * @Author: zhangwei12
 * @DateTime: 2017-11-16 6:16 PM
 * @Version: 1.0
 */
public class CustomeDecoder implements Decoder {
    @Override
    public Object decode(Response response, Type type) throws IOException, DecodeException, FeignException {
        Response.Body body = response.body();
        if (body == null) {
            return null;
        }
        return JSONObject.parseObject(Util.toString(body.asReader()), type);
    }
}
