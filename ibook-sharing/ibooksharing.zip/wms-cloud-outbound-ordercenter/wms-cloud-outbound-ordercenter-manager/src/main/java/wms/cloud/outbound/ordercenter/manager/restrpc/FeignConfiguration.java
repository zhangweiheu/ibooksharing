package wms.cloud.outbound.ordercenter.manager.restrpc;

import com.jd.wms.cloud.outbound.ordercenter.domain.common.HttpHeaderEnum;
import com.jd.wms.util.common.CommonUtil;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestVariableDefault;
import feign.Logger;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import feign.hystrix.HystrixFeign;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import wms.cloud.outbound.ordercenter.manager.restrpc.EnDecoder.CustomeDecoder;
import wms.cloud.outbound.ordercenter.manager.restrpc.auth.WarehouseInfoService;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 权限系统远程restRPC配置
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 7:40 PM
 * @Version: 1.0
 */
@Configuration
public class FeignConfiguration {
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(FeignConfiguration.class);
//    private static final HystrixRequestVariableDefault<Authentication> authentication = new HystrixRequestVariableDefault<>();
    private static final HystrixRequestVariableDefault<Map<String, Object>> headerInfo = new HystrixRequestVariableDefault<>();

    /**
     * 只关闭指定客户端的Hystrix支持创建一个Feign.Builder组件并标注为@Scope(prototype)
     *
     * @return
     */
    @Bean
    @Scope("prototype")
    public WarehouseInfoService warehouseInfoService() {
        return HystrixFeign.builder().decoder(new CustomeDecoder())
                .requestInterceptor(requestTokenBearerInterceptor())
                .target(WarehouseInfoService.class, "http://127.0.0.1:8080");
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }

//    private static HystrixRequestVariableDefault<Authentication> getAuthentication() {
//        return authentication;
//    }

    private static HystrixRequestVariableDefault<Map<String, Object>> getHeaderInfo() {
        return headerInfo;
    }

    @Bean
    public RequestInterceptor requestTokenBearerInterceptor() {
        return new RequestInterceptor() {

            @Override
            public void apply(RequestTemplate requestTemplate) {
//                Authentication auth = FeignConfiguration.getAuthentication().get();
//                if (auth != null) {
//                    logger.debug("try to forward the authentication by Hystrix, the Authentication Object: " + auth);
//                    // 记得，因为 Feign Interceptor 是通过自有的 ThreadPool 中的线程执行的，与当前的 Request 线程不是同一个线程，所以这里不能使用 debug 模式进行调试；
//                    requestTemplate.header("Authorization", "bearer " + ((OAuth2AuthenticationDetails) auth.getDetails()).getTokenValue());
//
//                } else {
//                    logger.debug("attention, there is no Authentication Object needs to forward");
//                }

                Map<String, Object> headInfo = FeignConfiguration.getHeaderInfo().get();
                String routeRule = (String) headInfo.get(CommonUtil.ROUTER_KEY);
                if (StringUtils.isNotBlank(routeRule)) {
                    requestTemplate.header(CommonUtil.ROUTER_KEY, routeRule);
                }
                String lang = (String) headInfo.get(HttpHeaderEnum.Lang.getKey());
                if (StringUtils.isNotBlank(lang)) {
                    requestTemplate.header(HttpHeaderEnum.Lang.getKey(), lang);
                }
            }
        };
    }

    @Bean
    public FilterRegistrationBean hystrixFilter() {
        FilterRegistrationBean r = new FilterRegistrationBean();
        r.setFilter(new Filter() {
            @Override
            public void init(FilterConfig filterConfig) throws ServletException {
            }

            @Override
            public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
                // as the comments described by HystrixRequestContext, for using HystrixRequestVariable should first initialize the context at the beginning of each request
                // so made it here...
                HystrixRequestContext.initializeContext();
                ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

                if (attributes != null) {
                    HttpServletRequest servletRequest = attributes.getRequest();
                    Enumeration<String> headerNames = servletRequest.getHeaderNames();
                    HashMap<String, Object> headinfoMap = new HashMap<>();
                    while (headerNames.hasMoreElements()) {
                        String name = headerNames.nextElement();
                        if (CommonUtil.ROUTER_KEY.equals(name) || HttpHeaderEnum.Lang.getKey().equals(name)) {
                            headinfoMap.put(name, servletRequest.getHeader(name));
                        }
                    }
                    FeignConfiguration.getHeaderInfo().set(headinfoMap);
                }
//                SecurityContext securityContext = SecurityContextHolder.getContext();
//                if (securityContext != null) {
//                    Authentication auth = securityContext.getAuthentication();
//                    FeignConfiguration.getAuthentication().set(auth);
//                    logger.debug("try to register the authentication into Hystrix Context, the Authentication Object: " + auth);
//                }
                chain.doFilter(request, response);
            }

            @Override
            public void destroy() {
            }
        });
        // In case you want the filter to apply to specific URL patterns only
        r.addUrlPatterns("/*");

        return r;
    }
}
