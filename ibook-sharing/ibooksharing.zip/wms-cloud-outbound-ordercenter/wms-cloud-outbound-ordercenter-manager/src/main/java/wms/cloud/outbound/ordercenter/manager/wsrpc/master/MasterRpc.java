package wms.cloud.outbound.ordercenter.manager.wsrpc.master;

import com.alibaba.fastjson.JSONObject;
import com.jd.bk.common.util.security.MD5Util;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.clientbean.Result;
import com.jd.wms.cloud.outbound.ordercenter.domain.rpc.service.Wms3MessageRpc;
import com.jd.wms.cloud.outbound.ordercenter.domain.user.UserInfo;
import com.jd.wms.domain.wms3.master.ws.User;
import com.jd.wms.domain.ws.receivemessage.param.BizToken;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 调用master服务
 * @Author: zhangwei12
 * @DateTime: 2017-10-26 5:21 PM
 * @Version: 1.0
 */
@Component(value = "masterRpc")
public class MasterRpc {
    private static final Logger logger = LoggerFactory.getLogger(CenterRpc.class);

    @Autowired
    @Qualifier(value = "authoritymsMessageRpc")
    private Wms3MessageRpc authoritymsMessageRpc;

    @Resource
    private BizToken queryUserInfoFromPower;

    public UserInfo getUserFromMaster(User user) {
        //设置http头
        Map<String, String> parameter = new HashMap<String, String>();
        parameter.put("userAccount", user.getUserName());
        parameter.put("userPwd", MD5Util.md5Hex(user.getUserPwd()));
        parameter.put("orgNo", user.getOrgNo());
        parameter.put("distributeNo", user.getDistributeNo());
        parameter.put("warehouseNo", user.getWarehouseNo());
        Result result = authoritymsMessageRpc.queryWs(JSONObject.toJSONString(queryUserInfoFromPower), JSONObject.toJSONString(parameter));
        if (result == null || result.getResultCode() != 1) {
            return null;
        }
        UserInfo userInfo = JSONObject.parseObject(result.getResultValue(), UserInfo.class);
        List<String> roles = userInfo.getRoleList();
        if (CollectionUtils.isEmpty(roles)) {
            return null;
        }
        return userInfo;
    }
}
