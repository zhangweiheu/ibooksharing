package wms.cloud.outbound.ordercenter.manager.restrpc.auth;

import com.jd.wms.cloud.outbound.ordercenter.domain.common.BaseDomain;
import com.jd.wms.stock.domain.exceptions.BusinessCommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description: 库房信息异常回调
 * @Author: zhangwei12
 * @DateTime: 2017-11-15 4:40 PM
 * @Version: 1.0
 */
@Component(value = "warehouseInfoFallBack")
public class WarehouseInfoFallBack implements WarehouseInfoService {
    private static final Logger LOGGER = LoggerFactory.getLogger(WarehouseInfoFallBack.class);

    @Override
    public List<BaseDomain> getWarehouseInfo() {
        LOGGER.error("走到这里啦");
        throw new BusinessCommonException("12345");
    }
}
