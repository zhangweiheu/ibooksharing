package wms.cloud.outbound.ordercenter.manager.order;

import com.jd.wms.stock.domain.stock.StStockM;

/**
 * @Description:
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 11:28 AM
 * @Version: 1.0
 */
public interface OrderManager {
    boolean insertStockM(StStockM bean);
}
