package wms.cloud.outbound.ordercenter.manager.restrpc.auth;

import com.jd.wms.cloud.outbound.ordercenter.domain.common.BaseDomain;
import feign.Headers;
import feign.RequestLine;
import org.springframework.cloud.netflix.feign.FeignClient;
import wms.cloud.outbound.ordercenter.manager.restrpc.FeignConfiguration;

import java.util.List;

/**
 * @Description: 库房信息
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 7:41 PM
 * @Version: 1.0
 */
@FeignClient(name = "warehouseInfoService", fallback = WarehouseInfoFallBack.class, primary = false, configuration = FeignConfiguration.class)
public interface WarehouseInfoService {

    @Headers({"Content-Type: application/json"})
    @RequestLine("GET /api/public/warehouse/info")
    List<BaseDomain> getWarehouseInfo();
}


