package wms.cloud.outbound.ordercenter.manager.order.impl;

import com.jd.wms.cloud.outbound.ordercenter.dao.mapper.OrderMapper;
import com.jd.wms.stock.domain.exceptions.BusinessCommonException;
import com.jd.wms.stock.domain.stock.StStockM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import wms.cloud.outbound.ordercenter.manager.order.OrderManager;

/**
 * @Description: 事务处理层
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 11:29 AM
 * @Version: 1.0
 */
@Repository
public class OrderManagerImpl implements OrderManager {

    @Autowired
    private OrderMapper orderMapper;

    /**
     * 正常开启事务,发生异常回滚
     * @param bean
     * @return
     */
    @Transactional
    public boolean insertStockM(StStockM bean){
        if(orderMapper.insert(bean) > 0){
            return true;
        }else {
            throw new BusinessCommonException(123456);
        }
    }

}
