package wms.cloud.outbound.ordercenter.manager.restrpc.EnDecoder;

import feign.RequestTemplate;
import feign.codec.EncodeException;
import feign.codec.Encoder;

import java.lang.reflect.Type;

/**
 * @Description: 自定义json编码
 * @Author: zhangwei12
 * @DateTime: 2017-11-16 6:16 PM
 * @Version: 1.0
 */
public class CustomeEncoder implements Encoder{
    @Override
    public void encode(Object object, Type bodyType, RequestTemplate template) throws EncodeException {

    }
}
