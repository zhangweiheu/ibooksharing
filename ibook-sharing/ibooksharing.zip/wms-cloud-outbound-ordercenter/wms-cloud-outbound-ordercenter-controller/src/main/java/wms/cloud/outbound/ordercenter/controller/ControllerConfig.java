package wms.cloud.outbound.ordercenter.controller;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

/**
 * @Description: controller config
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 6:50 PM
 * @Version: 1.0
 */
@Configuration
@ComponentScan(basePackages = {"wms.cloud.outbound.ordercenter.controller"}, excludeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class)})
public class ControllerConfig {
}
