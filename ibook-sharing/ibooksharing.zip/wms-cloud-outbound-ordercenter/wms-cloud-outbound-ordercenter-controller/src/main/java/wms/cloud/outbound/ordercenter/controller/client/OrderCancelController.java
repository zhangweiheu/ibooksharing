package wms.cloud.outbound.ordercenter.controller.client;

import com.jd.wms.cloud.outbound.ordercenter.domain.common.BaseDomain;
import com.jd.wms.cloud.outbound.ordercenter.domain.common.ClientTypeEnum;
import com.jd.wms.cloud.outbound.ordercenter.domain.user.UserDTO;
import com.jd.wms.cloud.outbound.ordercenter.domain.user.UserInfo;
import com.jd.wms.stock.domain.exceptions.BusinessCommonException;
import com.jd.wms.stock.domain.stock.StStockCarton;
import com.jd.wms.stock.domain.stock.StStockM;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import wms.cloud.outbound.ordercenter.manager.restrpc.auth.WarehouseInfoService;
import wms.cloud.outbound.ordercenter.manager.wsrpc.master.CenterRpc;
import wms.cloud.outbound.ordercenter.service.order.OrderService;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description: 订单取消
 * @Author: zhangwei12
 * @DateTime: 2017-11-09 6:53 PM
 * @Version: 1.0
 */
@Api(value = "API - OrderCancelController", description = "订单取消接口详情")
@RestController
@ResponseBody
@RequestMapping(value = "/api/outbound/ordercenter/ordercancel")
public class OrderCancelController {
    private static final Logger logger = LoggerFactory.getLogger(OrderCancelController.class);

    @Resource
    private CenterRpc centerRpc;

    @Autowired
    private OrderService orderService;

    @Resource
    private WarehouseInfoService warehouseInfoService;

    @ApiOperation(value = "取消订单", notes = "取消订单")
    @ApiImplicitParams({@ApiImplicitParam(name = "userInfo", value = "用户信息实体", required = true, dataType = "UserInfo")})
    @ApiResponses({@ApiResponse(code = 200, message = "请求成功"), @ApiResponse(code = 400, message = "请求数据不合法")})
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public List<BaseDomain> cancelOrder(@Validated UserInfo userInfo) {
        logger.info(userInfo.getPassword());
        UserDTO user = new UserDTO();
        user.setUserAccount("6");
        user.setPassword("6");
        user.setUserPwd("6");
        user.setOrgNo("6");
        user.setPassword("6");
        user.setClientType(ClientTypeEnum.RF);
        centerRpc.getMenuInfoByUserInfo(user);
        return null;
    }

    @ApiOperation(value = "新增库存", notes = "新增库存")
    @ApiImplicitParams({@ApiImplicitParam(name = "stStockM", value = "库存实体信息", required = true, dataType = "StStockM")})
    @ApiResponses({@ApiResponse(code = 200, message = "请求成功"), @ApiResponse(code = 400, message = "请求数据不合法")})
    @RequestMapping(value = "/insert/stream", method = RequestMethod.POST)
    public StStockCarton insertStock(@Validated StStockM stStockM) {
        StStockCarton stStockCarton = new StStockCarton();
        if (!orderService.insertStock(stStockM)) {
            throw new BusinessCommonException(12345);
        }
        return stStockCarton;
    }

    @ApiOperation(value = "查询库房信息", notes = "查询库房信息")
    @ApiResponses({@ApiResponse(code = 200, message = "请求成功"), @ApiResponse(code = 400, message = "请求数据不合法")})
    @RequestMapping(value = "/warehouse/info", method = RequestMethod.GET)
    public List<BaseDomain> insertStock() {
        return warehouseInfoService.getWarehouseInfo();
    }

}
