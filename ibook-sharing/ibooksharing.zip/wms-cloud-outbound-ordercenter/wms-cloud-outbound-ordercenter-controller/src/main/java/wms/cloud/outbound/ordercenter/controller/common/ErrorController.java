package wms.cloud.outbound.ordercenter.controller.common;

import com.jd.wms.stock.domain.exceptions.BusinessCommonException;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description: 接口异常的error跳转实现
 * @Author: zhangwei12
 * @DateTime: 2017-11-17 3:58 PM
 * @Version: 1.0
 */
@RestController
@RequestMapping(value = "/error")
@ResponseBody
public class ErrorController {
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ModelMap error() {
        throw new BusinessCommonException("12345");
    }
}
