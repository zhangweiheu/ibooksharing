package wms.cloud.outbound.ordercenter.controller;

import com.jd.wms.stock.domain.exceptions.BusinessCommonException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @Description: 异常统一拦截处理, 消息国际化
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 3:40 PM
 * @Version: 1.0
 */
@ControllerAdvice
public class ControllerExceptionAdvice {
    private static final Logger LOGGER = LoggerFactory.getLogger(ControllerExceptionAdvice.class);

    @Resource
    private ReloadableResourceBundleMessageSource messageResource;

    /**
     * 请求参数校验失败的结果
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({BindException.class, MethodArgumentNotValidException.class, ConstraintViolationException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ModelMap handleBindException(HttpServletRequest req, Exception ex) {
        LOGGER.warn("请求地址: {} 请求参数不合法:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        BindingResult result = null;
        if (ex instanceof BindException) {
            result = ((BindException) ex).getBindingResult();
            mav.addAttribute("exceptionMessage", result.getFieldError().getDefaultMessage());
        } else if (ex instanceof MethodArgumentNotValidException) {
            result = ((MethodArgumentNotValidException) ex).getBindingResult();
            mav.addAttribute("exceptionMessage", result.getFieldError().getDefaultMessage());
        } else {
            ConstraintViolationException e = (ConstraintViolationException) ex;
            mav.addAttribute("exceptionMessage", e.getConstraintViolations().iterator().next().getMessage());
        }
        return mav;
    }

    /**
     * 处理所有业务异常
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(BusinessCommonException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.EXPECTATION_FAILED)
    public ModelMap handleBusinessException(HttpServletRequest req, BusinessCommonException ex) {
        LOGGER.warn("请求地址: {} 出现业务异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", messageResource.getMessage(String.valueOf(ex.getResultCode()), ex.getParams(), LocaleContextHolder.getLocale()));
        return mav;
    }

    /**
     * 请求参数缺失、类型不匹配异常
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({MissingServletRequestParameterException.class, TypeMismatchException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ModelMap handleExceptionForBadRequest(HttpServletRequest req, Exception ex) {
        LOGGER.warn("请求地址: {} 提交的请求数据异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }

    /**
     * 请求方法不支持异常
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.METHOD_NOT_ALLOWED)
    public ModelMap handleException(HttpServletRequest req, HttpRequestMethodNotSupportedException ex) {
        LOGGER.warn("请求地址: {} 提交的HTTP METHOD不支持:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }

    /**
     * 处理IO其他异常
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(IOException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelMap handleIOException(HttpServletRequest req, IOException ex) {
        LOGGER.error("请求地址: {} IO异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }

    /**
     * 空指针异常
     *
     * @param req
     * @param ex
     * @return
     * @throws Exception
     */
    @ExceptionHandler({NullPointerException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelMap nullPointerExceptionHandler(HttpServletRequest req, NullPointerException ex) throws Exception {
        LOGGER.error("请求地址: {} 空指针异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }

    /**
     * 数据库操作异常
     *
     * @param req
     * @param ex
     * @return
     * @throws Exception
     */
    @ExceptionHandler({SQLException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelMap mysqlExceptionHandler(HttpServletRequest req, SQLException ex) throws Exception {
        LOGGER.error("请求地址: {} 数据库数据异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }

    /**
     * 处理其他异常
     *
     * @param req
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelMap handleException(HttpServletRequest req, Exception ex) {
        LOGGER.error("请求地址: {} 程序出现未知异常:", req.getRequestURL(), ex);
        ModelMap mav = new ModelMap();
        mav.addAttribute("exceptionMessage", ex.getMessage());
        return mav;
    }
}
