package com.jd.wms.cloud.outbound.ordercenter.application.config;

import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @Description:
 * @Author: zhangwei12
 * @DateTime: 2017-11-14 10:27 PM
 * @Version: 1.0
 */
@EnableSwagger2
public class SwaggerConfig {
    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo())
                .genericModelSubstitutes(ResponseEntity.class)
                .forCodeGeneration(false)
//                .pathMapping(pathMapping)
                .select()
                .apis(RequestHandlerSelectors.basePackage("wms.cloud.outbound.ordercenter.controller"))
                .paths(PathSelectors.any()).build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("springboot利用swagger构建api文档").description("出库ordercenter Restful 接口")
                .termsOfServiceUrl("localhost:8081").version("1.0").build();
    }
}
