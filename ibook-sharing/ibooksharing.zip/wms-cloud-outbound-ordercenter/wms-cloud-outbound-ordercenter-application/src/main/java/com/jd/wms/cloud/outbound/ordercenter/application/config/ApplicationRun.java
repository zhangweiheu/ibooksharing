package com.jd.wms.cloud.outbound.ordercenter.application.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.context.request.RequestContextListener;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

/**
 * @Description: 应用启动类
 * @Author: zhangwei12
 * @DateTime: 2017-10-24 5:48 PM
 * @Version: 1.0
 */
@SpringBootApplication
public class ApplicationRun extends SpringBootServletInitializer {
    @Override
    protected final SpringApplicationBuilder configure(final SpringApplicationBuilder application) {
        return application.sources(ApplicationConfig.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(ApplicationConfig.class, args);
    }

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        servletContext.addListener(requestContextListener());
        super.onStartup(servletContext);

    }
    @Bean
    public RequestContextListener requestContextListener(){
        return new RequestContextListener();
    }
}
