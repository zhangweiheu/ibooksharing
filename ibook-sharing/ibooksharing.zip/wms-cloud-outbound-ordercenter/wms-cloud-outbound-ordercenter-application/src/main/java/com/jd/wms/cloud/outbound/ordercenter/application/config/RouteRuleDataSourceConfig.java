package com.jd.wms.cloud.outbound.ordercenter.application.config;

import com.jd.wms.util.soap.*;
import org.apache.ibatis.mapping.DatabaseIdProvider;
import org.apache.ibatis.plugin.Interceptor;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.boot.autoconfigure.MybatisProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.bind.RelaxedDataBinder;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.env.Environment;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 路由配置
 * @Author: zhangwei12
 * @DateTime: 2017-11-13 10:58 AM
 * @Version: 1.0
 */
@Configuration
@PropertySource({"classpath:/appconfig.properties", "classpath:/important.properties", "classpath:/common-datasource.properties"})
@EnableConfigurationProperties({MybatisProperties.class})
public class RouteRuleDataSourceConfig implements TransactionManagementConfigurer {
    private static final Logger LOGGER = LoggerFactory.getLogger(RouteRuleDataSourceConfig.class);
    @Autowired
    private MybatisProperties properties;

    @Autowired
    private ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Autowired(required = false)
    private Interceptor[] interceptors;

    @Autowired(required = false)
    private DatabaseIdProvider databaseIdProvider;

    /**
     * 默认数据源类型
     */
    private static final String DATASOURCE_TYPE_DEFAULT = "org.apache.commons.dbcp2.BasicDataSource";
    private Map<String, DataSource> multiDataSources = new HashMap<String, DataSource>();

    /**
     * 通用属性值:wms.common.dataSource.properties.具体属性名称=属性值
     */
    private static final String commonPropertiesPrefix = "wms.common.dataSource.properties.";

    /**
     * 每个数据源单独的属性值wms.jdbc.private.数据源名称.属性=属性值
     */
    private static final String UUPPropertiesPrefix = "wms.jdbc.private.";

    /**
     * key前缀名称必须是wms.dataSource.name.数据源名称=数据源名称
     */
    private static final String dataSourceNamePrefix = "wms.dataSource.name.";

    private ConversionService conversionService = new DefaultConversionService();

    @Autowired
    private Environment env;

    public RouteRuleDataSourceConfig(MybatisProperties properties) {
        this.properties = properties;
    }

    @Bean
    public DataSourceTransactionManager createDataSourceManager() {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
        transactionManager.setDataSource(initDataSources());
        return transactionManager;
    }

    @Override
    public PlatformTransactionManager annotationDrivenTransactionManager() {
        return createDataSourceManager();
    }

    @Bean(name = "sqlSessionFactory")
    public SqlSessionFactoryBean createSqlSessionFactoryBean() throws SQLException, IOException {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(createDataSourceManager().getDataSource());
        if (StringUtils.hasText(this.properties.getConfigLocation())) {
            factoryBean.setConfigLocation(this.resourceLoader.getResource(this.properties.getConfigLocation()));
        }
        if (!ObjectUtils.isEmpty(this.interceptors)) {
            factoryBean.setPlugins(interceptors);
        }
        if (this.databaseIdProvider != null) {
            factoryBean.setDatabaseIdProvider(this.databaseIdProvider);
        }
        if (StringUtils.hasLength(this.properties.getTypeAliasesPackage())) {
            factoryBean.setTypeAliasesPackage(this.properties.getTypeAliasesPackage());
        }
        if (StringUtils.hasLength(this.properties.getTypeHandlersPackage())) {
            factoryBean.setTypeHandlersPackage(this.properties.getTypeHandlersPackage());
        }
        if (!ObjectUtils.isEmpty(this.properties.resolveMapperLocations())) {
            factoryBean.setMapperLocations(this.properties.resolveMapperLocations());
        }
        return factoryBean;
    }

    @Bean
    public RouterDataSource initDataSources() {
        RouterDataSource routerDataSource = new RouterDataSource();
        Map<String, Object> commonMap = new RelaxedPropertyResolver(env, commonPropertiesPrefix).getSubProperties("");
        PropertyValues commonPropertyValues = new MutablePropertyValues(commonMap);
        RelaxedPropertyResolver allPrivateProperties = new RelaxedPropertyResolver(env, UUPPropertiesPrefix);
        Map<String, Object> nameMap = new RelaxedPropertyResolver(env, dataSourceNamePrefix).getSubProperties("");
        for (String dataSourceName : nameMap.keySet()) {
            PropertyValues singlePrivatePropertyValues = new MutablePropertyValues(allPrivateProperties.getSubProperties(dataSourceName + "."));
            multiDataSources.put(dataSourceName, buildDataSource(singlePrivatePropertyValues, commonPropertyValues));
        }
        if (multiDataSources.size() <= 0) {
            LOGGER.error("多数据源配置未生效");
        }
        routerDataSource.setDataSourceMap(multiDataSources);
        return routerDataSource;
    }

    /**
     * 创建数据源
     *
     * @param privatePropertyValues
     * @return
     */
    private DataSource buildDataSource(PropertyValues privatePropertyValues, PropertyValues commonPropertyValues) {
        Object type = privatePropertyValues.getPropertyValue("type").getValue();
        if (type == null) {
            type = DATASOURCE_TYPE_DEFAULT;
        }
        Class<? extends DataSource> dataSourceType;
        try {
            dataSourceType = (Class<? extends DataSource>) Class.forName((String) type);
            DataSourceBuilder factory =
                    DataSourceBuilder.create().driverClassName((String) privatePropertyValues.getPropertyValue("driverClassName").getValue()).url((String) privatePropertyValues.getPropertyValue("url").getValue()).username((String) privatePropertyValues.getPropertyValue("username").getValue()).password((String) privatePropertyValues.getPropertyValue("password").getValue()).type(dataSourceType);
            DataSource dataSource = factory.build();
            dataBinder(dataSource, commonPropertyValues);
            dataBinder(dataSource, privatePropertyValues);
            return dataSource;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 数据源绑定反射绑定属性
     *
     * @param dataSource
     */
    private void dataBinder(DataSource dataSource, PropertyValues propertyValues) {
        RelaxedDataBinder dataBinder = new RelaxedDataBinder(dataSource);
        dataBinder.setConversionService(conversionService);
        dataBinder.setIgnoreNestedProperties(false);//false
        dataBinder.setIgnoreInvalidFields(false);//false
        dataBinder.setIgnoreUnknownFields(true);//true
        dataBinder.bind(propertyValues);
    }
}
