package com.jd.wms.cloud.outbound.ordercenter.application.config;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.jd.wms.cloud.outbound.ordercenter.dao.DaoConfig;
import com.jd.wms.cloud.outbound.ordercenter.domain.common.HttpHeaderEnum;
import com.jd.wms.util.common.CommonUtil;
import com.jd.wms.util.soap.*;
import org.hibernate.validator.HibernateValidator;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.HttpPutFormContentFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import wms.cloud.outbound.ordercenter.controller.ControllerConfig;
import wms.cloud.outbound.ordercenter.manager.ManagerConfig;
import wms.cloud.outbound.ordercenter.manager.restrpc.FeignConfiguration;
import wms.cloud.outbound.ordercenter.service.ServiceConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description: 工程配置类
 * @Author: zhangwei12
 * @DateTime: 2017-10-24 7:07 PM
 * @Version: 1.0
 */
@EnableWebMvc
@Configuration
@ComponentScan
@ImportResource({"classpath:/config/**/*.xml"})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@Import({RouteRuleDataSourceConfig.class, ControllerConfig.class, ServiceConfig.class, ManagerConfig.class, DaoConfig.class, SwaggerConfig.class, FeignConfiguration.class})
@EnableTransactionManagement
@EnableFeignClients
@EnableCircuitBreaker
@PropertySource(value = "classpath:/feign-hystrix.properties")
public class ApplicationConfig extends WebMvcConfigurerAdapter {
    /**
     * 支持PUT请求
     */
    @Bean
    public HttpPutFormContentFilter httpPutFormContentFilter() {
        return new HttpPutFormContentFilter();
    }

    /**
     * 统一UTF-8编码
     */
    @Bean
    public CharacterEncodingFilter characterEncodingFilter() {
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8");
        characterEncodingFilter.setForceEncoding(true);
        return characterEncodingFilter;
    }



    /**
     * 拦截器链依次拦截处理
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
        registry.addInterceptor(createRouteRuleHeaderInterceptor()).excludePathPatterns("swagger-ui.html", "/webjars/**", "/swagger-resources", "/v2/api-docs", "/configuration/**", "/hystrix.stream");
        super.addInterceptors(registry);
    }

    @Bean
    public FastJsonHttpMessageConverter createFastJsonHttpMessageConverter() {
        FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
        // 2 添加fastjson 的配置信息 比如 是否要格式化 返回的json数据
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        fastJsonConfig.setSerializerFeatures(SerializerFeature.PrettyFormat);
        fastConverter.setFastJsonConfig(fastJsonConfig);
        // 解决乱码的问题
        List<MediaType> fastMediaTypes = new ArrayList<MediaType>();
        fastMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        fastConverter.setSupportedMediaTypes(fastMediaTypes);
        return fastConverter;
    }

    /**
     * 配置fastJson 用于替代jackson
     */
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        super.configureMessageConverters(converters);
        converters.add(createFastJsonHttpMessageConverter());
    }

    /**
     * 全局异常解析
     **/
    @Override
    public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
        super.configureHandlerExceptionResolvers(exceptionResolvers);
    }

    /**
     * swagger
     *
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    /**
     * 国际化校验信息配置
     *
     * @return
     */
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
        lci.setParamName(HttpHeaderEnum.Lang.getKey());
        return lci;
    }

    /**
     * IoC容器的国际化资源
     *
     * @return
     */
    @Bean(name = "messageResource")
    public MessageSource getMessageResource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames("classpath:message/messages", "classpath:messages/Validation");
        messageSource.setUseCodeAsDefaultMessage(false);
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setCacheSeconds(3600);
        return messageSource;
    }

    @Bean
    public LocalValidatorFactoryBean defaultValidator() {
        LocalValidatorFactoryBean factoryBean = new LocalValidatorFactoryBean();
        factoryBean.setProviderClass(HibernateValidator.class);
        factoryBean.setValidationMessageSource(getMessageResource());
        return factoryBean;
    }

    @Override
    public Validator getValidator() {
        return defaultValidator();
    }

    @Bean
    public WMSCtxInitor createWMSCtxInitor() {
        WMSCtxInitorImpl wmsCtxInitor = new WMSCtxInitorImpl();
        return wmsCtxInitor;
    }

    @Bean
    public WMSCtxConfigure createWMSCtxConfigure() {
        WMSCtxConfigureByFileImpl configureByFile = new WMSCtxConfigureByFileImpl();
        return configureByFile;
    }

    @Bean
    public RouteRuleHeaderInterceptor createRouteRuleHeaderInterceptor() {
        CommonUtil commonUtil = createCommonRouteRuleUtil();
        RouteRuleHeaderInterceptor ruleHeaderInterceptor = new RouteRuleHeaderInterceptor();
        ruleHeaderInterceptor.setConfigure(commonUtil.getConfigure());
        ruleHeaderInterceptor.setInitor(commonUtil.getInitor());
        return ruleHeaderInterceptor;
    }

    @Bean
    public CommonUtil createCommonRouteRuleUtil() {
        CommonUtil commonUtil = new CommonUtil();
        commonUtil.setConfigure(createWMSCtxConfigure());
        commonUtil.setInitor(createWMSCtxInitor());
        return commonUtil;
    }
}

